// This file is used to configure PostCSS with Tailwind CSS

export default {
  plugins: {
    '@tailwindcss/postcss': {},
    autoprefixer: {},
  },
};
