import { useState } from 'react'
import './App.css'
import AceEditor from "react-ace";
import "ace-builds/src-noconflict/mode-json";
import "ace-builds/src-noconflict/theme-github";
import "ace-builds/src-noconflict/theme-monokai";
/**
 * App.jsx
 * Um simples formatador de JSON usando React e Tailwind CSS.
 * Permite colar um JSON, formatá-lo e exibir o resultado.
 */

export default function App() {
  const [input, setInput] = useState("");
  const [output, setOutput] = useState("");
  const [error, setError] = useState("");
  const [darkMode, setDarkMode] = useState(false);

  const formatJSON = () => {
    try {
      const parsed = JSON.parse(input);
      const pretty = JSON.stringify(parsed, null, 2);
      setOutput(pretty);
      setError("");
    } catch {
      setError("JSON inválido! Verifique a sintaxe.");
    }
  };

  return (
    <div className=" gap-5">
      <h1 className="text-2xl font-bold mb-10">🔧 Formatador de JSON</h1>
      <div className="bg-red-500 m-10">
        <textarea
          className="w-full h-48 p-2 border rounded mb-10 resize-none"
          rows="10"
          cols="80"
          placeholder="Cole seu JSON aqui..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
        />
        <div className=" mt-4">
          <button
            onClick={formatJSON}
            className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
          >
            Formatar
          </button>
        </div>

      </div>
      <div className="flex mt-5">
        {output && (
          <div className="flex mt-4">
            <AceEditor
              mode="json"
              theme={darkMode ? "monokai" : "github"}
              name="json-output"
              value={output}
              readOnly={true}
              fontSize={14}
              width="100%"
              height="300px"
              setOptions={{
                useWorker: false,
                showLineNumbers: true,
                tabSize: 2,
              }}
            />
            {/* <button
              onClick={() => setDarkMode((d) => !d)}
              className="px-4 py-2 rounded border border-gray-400 dark:border-gray-600 bg-gray-200 dark:bg-gray-800 text-gray-800 dark:text-gray-200 hover:bg-gray-300 dark:hover:bg-gray-700 transition"
            >
              {darkMode ? "☀️ Claro" : "🌙 Escuro"}
            </button> */}
          </div>
        )}
      </div>
      <div className="col-span-6 col-start-1 row-start-1">

      </div>
      <div className="col-span-6 row-span-2 row-start-5">


        {error && <p className="text-red-600 mt-2">{error}</p>}
      </div>
    </div>
  );
}


